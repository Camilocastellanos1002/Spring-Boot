package com.riwi.primerWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimerWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimerWebApplication.class, args);
	}

}
