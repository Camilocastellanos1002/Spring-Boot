package com.riwi.primerWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimerWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
